
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ExamPHP</title>
</head>
<body>
    <form action="index.php" method="POST">
        <label for="reverse">Input the text</label>
        <input type="text" name="reverse" id="reverse">
        <input type="submit" value="submit" name="submit">
    </form>
    <?php include 'functions.php';?>
</body>
</html>




